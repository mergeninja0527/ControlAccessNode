/**
 * OpenAPI 3.0 spec for Control de Acceso backend.
 * Served at /api-docs when Swagger UI is mounted.
 */
const PORT = process.env.PORT || 3000;

module.exports = {
  openapi: '3.0.3',
  info: {
    title: 'Control de Acceso API',
    description: 'Backend API for ZKTeco access control: auth, invitations, access validation, buildings, users, devices.',
    version: '1.0.0',
  },
  servers: [
    { url: `http://localhost:${PORT}`, description: 'Local' },
    { url: '/', description: 'Current host' },
  ],
  tags: [
    { name: 'Auth', description: 'Login' },
    { name: 'Invitations', description: 'Visitor invitations and QR' },
    { name: 'Access', description: 'QR validation and door access' },
    { name: 'Door', description: 'Door control' },
    { name: 'Mobile', description: 'Mobile app endpoints' },
    { name: 'Buildings', description: 'Edificio, Piso, Sala, Ubicación' },
    { name: 'Users', description: 'Usuarios y roles' },
    { name: 'Devices', description: 'Dispositivos ZKTeco' },
    { name: 'Sync', description: 'Fingerprint and user sync' },
  ],
  paths: {
    '/auth/login': {
      post: {
        tags: ['Auth'],
        summary: 'Login',
        description: 'Login with RUT (username) and full name. No password.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['username', 'fullName'],
                properties: {
                  username: { type: 'string', description: 'RUT (e.g. 12345678-5)' },
                  fullName: { type: 'string', description: 'Full name' },
                },
              },
            },
          },
        },
        responses: {
          200: { description: 'OK', content: { 'application/json': { schema: { type: 'object', properties: { username: { type: 'string' }, user: { type: 'string' }, userrol: { type: 'number' }, passTemp: { type: 'number' } } } } } },
          403: { description: 'Invalid credentials' },
        },
      },
    },

    '/invitations': {
      get: {
        tags: ['Invitations'],
        summary: 'List invitations',
        description: 'List invitations created by a user.',
        parameters: [
          { name: 'userId', in: 'query', required: true, schema: { type: 'string' }, description: 'Creator RUT (IDUsuario)' },
        ],
        responses: { 200: { description: 'List of invitations' } },
      },
      post: {
        tags: ['Invitations'],
        summary: 'Create invitation',
        description: 'Create a visitor invitation and get QR code.',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['createdBy', 'nombreInvitado', 'fechaInicio', 'fechaFin'],
                properties: {
                  createdBy: { type: 'string', description: 'Creator RUT' },
                  nombreInvitado: { type: 'string' },
                  rutInvitado: { type: 'string' },
                  correoInvitado: { type: 'string' },
                  telefonoInvitado: { type: 'string' },
                  tipoInvitacion: { type: 'string', enum: ['Visitante', 'Delivery'] },
                  motivo: { type: 'string' },
                  fechaInicio: { type: 'string', format: 'date-time' },
                  fechaFin: { type: 'string', format: 'date-time' },
                  idSala: { type: 'integer' },
                  usageLimit: { type: 'integer', default: 1 },
                },
              },
            },
          },
        },
        responses: {
          201: { description: 'Invitation created', content: { 'application/json': { schema: { type: 'object', properties: { success: { type: 'boolean' }, data: { type: 'object', properties: { idAcceso: { type: 'string' }, qrCode: { type: 'string' } } } } } } } },
          400: { description: 'Validation error' },
        },
      },
    },
    '/invitations/link-device': {
      post: {
        tags: ['Invitations'],
        summary: 'Link device to invitation room',
        requestBody: {
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  idAcceso: { type: 'string' },
                  sn: { type: 'string' },
                  puerta: { type: 'string' },
                },
              },
            },
          },
        },
        responses: { 200: { description: 'OK' } },
      },
    },
    '/invitations/{id}': {
      get: {
        tags: ['Invitations'],
        summary: 'Get invitation by ID',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' }, description: 'IDAcceso' }],
        responses: { 200: { description: 'Invitation details' }, 404: { description: 'Not found' } },
      },
      delete: {
        tags: ['Invitations'],
        summary: 'Delete invitation',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'Deleted' } },
      },
    },
    '/invitations/{id}/cancel': {
      post: {
        tags: ['Invitations'],
        summary: 'Cancel invitation',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'Cancelled' } },
      },
    },
    '/invitations/{id}/events': {
      get: {
        tags: ['Invitations'],
        summary: 'Get invitation access events',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'string' } }],
        responses: { 200: { description: 'List of events' } },
      },
    },

    '/access/validate-qr': {
      post: {
        tags: ['Access'],
        summary: 'Validate QR for access',
        description: 'Validates QR code and returns access result (e.g. for door opening).',
        requestBody: {
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  qrCode: { type: 'string', description: 'ID/code from QR' },
                  sn: { type: 'string', description: 'Device serial' },
                  puerta: { type: 'string', description: 'Door id' },
                },
              },
            },
          },
        },
        responses: { 200: { description: 'Validation result' }, 403: { description: 'Invalid/expired' } },
      },
    },

    '/door/open': {
      post: {
        tags: ['Door'],
        summary: 'Open door',
        requestBody: {
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  sn: { type: 'string' },
                  puerta: { type: 'string' },
                },
              },
            },
          },
        },
        responses: { 200: { description: 'OK' } },
      },
    },

    '/mobile/auth/login': {
      post: {
        tags: ['Mobile'],
        summary: 'Mobile login',
        responses: { 200: { description: 'OK' } },
      },
    },
    '/mobile/obtainQR': {
      post: { tags: ['Mobile'], summary: 'Obtain QR' },
    },
    '/mobile/obtainQR/{user}': {
      get: { tags: ['Mobile'], summary: 'Get QR for user' },
    },
    '/mobile/visita': {
      post: { tags: ['Mobile'], summary: 'Add visit' },
    },
    '/mobile/registrar': {
      post: { tags: ['Mobile'], summary: 'Register user' },
    },
    '/mobile/createUser': {
      post: { tags: ['Mobile'], summary: 'Create user (alias)' },
    },
    '/mobile/check-rut': {
      post: { tags: ['Mobile'], summary: 'Check if RUT exists' },
    },
    '/mobile/get-user-by-rut': {
      post: { tags: ['Mobile'], summary: 'Get user by RUT' },
    },
    '/mobile/unidades': {
      get: { tags: ['Mobile'], summary: 'Get units (salas)' },
    },

    '/edificio': {
      get: { tags: ['Buildings'], summary: 'List buildings' },
      post: { tags: ['Buildings'], summary: 'Create building' },
    },
    '/edificio/select': {
      get: { tags: ['Buildings'], summary: 'Buildings for select' },
    },
    '/edificio/{idEdificio}': {
      patch: { tags: ['Buildings'], summary: 'Update building' },
      delete: { tags: ['Buildings'], summary: 'Delete building' },
    },

    '/piso': {
      get: { tags: ['Buildings'], summary: 'List floors' },
      post: { tags: ['Buildings'], summary: 'Create floor' },
    },
    '/piso/select': {
      get: { tags: ['Buildings'], summary: 'Floors for select' },
    },
    '/piso/{idPiso}': {
      patch: { tags: ['Buildings'], summary: 'Update floor' },
      delete: { tags: ['Buildings'], summary: 'Delete floor' },
    },

    '/sala': {
      get: { tags: ['Buildings'], summary: 'List rooms' },
      post: { tags: ['Buildings'], summary: 'Create room' },
    },
    '/sala/select': {
      get: { tags: ['Buildings'], summary: 'Rooms for select' },
    },
    '/sala/full/select': {
      get: { tags: ['Buildings'], summary: 'Rooms full select' },
    },
    '/sala/{idSala}': {
      patch: { tags: ['Buildings'], summary: 'Update room' },
      delete: { tags: ['Buildings'], summary: 'Delete room' },
    },

    '/ubicacion': {
      get: { tags: ['Buildings'], summary: 'List locations' },
      post: { tags: ['Buildings'], summary: 'Create location' },
    },
    '/ubicacion/{idPiso}': {
      delete: { tags: ['Buildings'], summary: 'Delete location' },
    },

    '/usuario': {
      get: { tags: ['Users'], summary: 'List users' },
      post: { tags: ['Users'], summary: 'Create user' },
    },
    '/usuario/enlace': {
      get: { tags: ['Users'], summary: 'Get user link' },
      post: { tags: ['Users'], summary: 'Create user link' },
    },
    '/usuario/{idUsuario}': {
      delete: { tags: ['Users'], summary: 'Delete user' },
    },
    '/rol/select/{idUsuario}': {
      get: { tags: ['Users'], summary: 'Roles select for user' },
    },

    '/dispositivos': {
      get: { tags: ['Devices'], summary: 'List devices' },
    },
    '/dispositivos/select': {
      get: { tags: ['Devices'], summary: 'Devices for select' },
    },
    '/dispositivos/doors/select/{searchSN}': {
      get: { tags: ['Devices'], summary: 'Doors for device' },
    },

    '/sync/fingerprint': {
      post: { tags: ['Sync'], summary: 'Sync fingerprint' },
      delete: { tags: ['Sync'], summary: 'Delete fingerprint sync' },
    },
    '/sync/user': {
      post: { tags: ['Sync'], summary: 'Sync user' },
      delete: { tags: ['Sync'], summary: 'Delete user sync' },
    },
    '/sync/count/fingerprint': {
      get: { tags: ['Sync'], summary: 'Fingerprint sync count' },
    },
    '/sync/count/user': {
      get: { tags: ['Sync'], summary: 'User sync count' },
    },

    '/ws/user/{rut}': {
      get: { tags: ['Users'], summary: 'Find user by RUT (ws)' },
    },
    '/ws/fingerprint': {
      post: { tags: ['Users'], summary: 'Save fingerprint' },
    },

    '/emp': {
      get: { tags: ['Devices'], summary: 'List employees (emp)' },
      post: { tags: ['Devices'], summary: 'Add emp' },
      delete: { tags: ['Devices'], summary: 'Delete emp' },
    },
    '/empServlet': {
      post: { tags: ['Devices'], summary: 'Emp servlet' },
    },
  },
};
